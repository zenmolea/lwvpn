import lwvpn
args=["","client", "vpn.key", "170.106.178.152", "1959"]

lwvpn.run(args)